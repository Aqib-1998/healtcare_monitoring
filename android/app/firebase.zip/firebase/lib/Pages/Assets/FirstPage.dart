import 'package:flutter/material.dart';

import 'Buttons.dart';

class UI extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Colors.grey[300],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(child: Text("Sign-in",style: TextStyle(fontSize: 32,color: Colors.black,fontWeight: FontWeight.w500),)),
          SizedBox(height: 48,),
          CustomButton(
            color: Colors.teal[700],
            child: Text("Login with Email",style: TextStyle(color: Colors.white,fontSize: 15.0,fontWeight: FontWeight.bold),),
            onPressed: (){},
          ),
          SizedBox(height: 8,),
          Center(child: Text("or",style: TextStyle(fontSize: 15,color: Colors.black,fontWeight: FontWeight.w500))),
          SizedBox(height: 8,),
          SignInButton(
            text: "Login with Google",
            imagePath: 'images/google-logo.png',
            textColor: Colors.black87,
            color: Colors.white,
            onPressed: (){},
          ),
          SizedBox(height: 8,),
          SignInButton(
            text: "Login with Facebook",
            imagePath: 'images/facebook-logo.png',
            textColor: Colors.white,
            color: Color(0xFF334D92),
            onPressed: (){},
          ),

        ],
      ),
    );
  }
}
