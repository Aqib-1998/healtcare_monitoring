






import 'package:flutter/material.dart';

import 'Pages/LoginPage.dart';

void main() {
  runApp(MaterialApp(
    home: LoginPage(),
    theme: ThemeData(
      primarySwatch: Colors.deepPurple,
    ),
  ));
}








































// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_core/firebase_core.dart';
//
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//
//   runApp(MaterialApp(home: homepage()));
// }
//
// //
// // class testdatabase extends StatelessWidget {
// //   var firestoreDb = FirebaseFirestore.instance.collection("testvalues").snapshots();
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return MaterialApp(
// //       home: Scaffold(
// //         appBar: AppBar(
// //           title: Text('retreiving data from firebase'),
// //           centerTitle: true,
// //         ),
// //         body: StreamBuilder(
// //
// //           stream: firestoreDb,
// //           builder: (context,snapshot){
// //             if(!snapshot.hasData) return CircularProgressIndicator();
// //             return ListView.builder(
// //                 itemCount: snapshot.data.documents.length,
// //                 itemBuilder: (context, int index){
// //                   return Text(snapshot.data.documents[index]["temperature"],style: TextStyle(color: Colors.black, fontSize: 55),);
// //             },
// //
// //             );
// //
// //           },
// //         ),
// //       ),
// //     );
// //   }
// // }
//
//
//
// //
// // void main() => runApp( MaterialApp(
// //
// //   debugShowCheckedModeBanner: false,
// //   home: homepage(),
// //
// // ));
//
// class homepage extends StatefulWidget {
//   @override
//   _homepageState createState() => _homepageState();
// }
//
// class _homepageState extends State<homepage> {
//   @override
//
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("test"),),
//       body: StreamBuilder(
//         stream: FirebaseFirestore.instance.collection("testvalues").snapshots(),
//         builder: (context, snapshot){
//           if(!snapshot.hasData) return Text('loading data.. plz wait');
//           return Column(
//             children: [
//               Text(snapshot.data.documents[0]['temperature'].toString()),
//             ],
//           );
//         },
//
//       ),
//     );
//
//   }
// }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
